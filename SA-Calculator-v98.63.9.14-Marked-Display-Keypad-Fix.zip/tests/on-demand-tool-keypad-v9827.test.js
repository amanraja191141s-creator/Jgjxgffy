const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('only the basic calculator has a permanent keypad; every tool uses on-demand keypad', () => {
  assert.match(js, /const PERMANENT_DOCKED_SCREENS = new Set\(\['calc'\]\)/);
  assert.match(js, /One consistent, on-demand keypad for every tool/);
  assert.match(js, /Tool screens intentionally start with no selected field and no keyboard/);
  assert.match(css, /\.screen:not\(#screen-calc\) > \.dock-keypad\s*\{\s*display:none !important/);
  assert.match(html, /id="popup-keypad-sheet"/);
});

test('tool keyboard opens only after tapping an editable numeric field', () => {
  const clickBranch = js.slice(js.indexOf("document.addEventListener('click', (e) => {\n    const input = findNumericPopupTarget"), js.indexOf('// Docked Keypad clicks'));
  assert.match(clickBranch, /STATE\.currentScreen === 'calc'/);
  assert.match(clickBranch, /openPopupKeypad\(input\)/);
  assert.doesNotMatch(clickBranch, /PERMANENT_DOCKED_SCREENS\.has\(STATE\.currentScreen\)/);
});
